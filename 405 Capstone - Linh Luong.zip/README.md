# Data-analytics-training-per-scholas
This repository is my data analyst capstone for graduation with Per Scholas.
In this Repository you will find 4 folders for each requirement of the project.
405 Capstone Python Application Development folder contain all python file to run application.
405 Capstone Loan Application Dataset folder contain python code to retrieve data from API and write data into CSV, Json file as well as import data into RDBMS
405 PowerBI Data Analysis and Visualization folder contain a powerBI file for visualization with credit card, customer and branch dataset
405 Capstone Loan Application Analysis and Visualization folder contain powerBI file for visualization with loan applicant data readed from the API and image of the required visualization